<?php
/*
Plugin Name: Page Hits & IP Counter
Version: 1.0.0
Plugin URI: https://www.facebook.com/webztechy
Description: Page hits and IP address counter.
Author: Webztechy
Author URI: https://www.facebook.com/webztechy
License: GPLv3.0 or later
*/


if( !class_exists('webztechy_page_ip_counter_admin') ) {

	
	class  webztechy_page_ip_counter_admin{
	
		public function __construct() {
			global $wpdb;
			
			add_action( 'admin_menu', array($this,'settings'));
			
		}
		
		/** This method render a submenu on configuration */
		public function settings(){

			add_menu_page('Newsletter', 'Page Hits & IP Counter', 'administrator', 'simplenewsletter-grid', array($this,'admin_gridSubscribers'), 'dashicons-visibility');
	
			add_submenu_page( 'simplenewsletter-grid', 'Newsletter Send', 'Newsletter Send', 'administrator', 'simplenewsletter-send', array($this,'admin_sendSubscribers'), 'dashicons-groups' ); 
			
			add_submenu_page( 'simplenewsletter-grid', 'Newsletter Setting', 'Newsletter Setting', 'administrator', 'simplenewsletter-setting', array($this,'admin_updateSettings'), 'dashicons-groups' ); 
			
			
		}

	} // end class webztechy_page_ip_counter_admin
	
}


/**
 * RUN admin setting class and functions
 * @since    1.0.0
 *
 */
	
if( class_exists('webztechy_page_ip_counter_admin') ) {
	$webztechy_page_ip_counter_admin = new webztechy_page_ip_counter_admin();
	

}




?>
